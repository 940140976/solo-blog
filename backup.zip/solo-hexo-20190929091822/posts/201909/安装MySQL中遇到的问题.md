title: 安装MySQL中遇到的问题
date: '2019-09-27 17:38:07'
updated: '2019-09-28 10:05:41'
tags: [java]
permalink: /articles/2019/09/27/1569577087279.html
---
**[MySQL安装和重置密码]**
[查看博客](https://blog.csdn.net/xsfqh/article/details/90085168#commentBox)

**[初次修改密码]**
[查看博客](https://www.cnblogs.com/gkx0731/p/9739241.html)

**[在使用Navicat Premium 12连接MySQL数据库时会出现Authentication plugin 'caching_sha2_password' cannot be loaded的错误]**
[查看解决方法](https://blog.csdn.net/u011182575/article/details/80821418)
