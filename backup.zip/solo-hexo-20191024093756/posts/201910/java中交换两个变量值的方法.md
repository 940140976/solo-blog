title: java中交换两个变量值的方法
date: '2019-10-17 20:54:58'
updated: '2019-10-17 20:57:05'
tags: [算法]
permalink: /articles/2019/10/17/1571316898484.html
---
1. 引入temp临时变量
```
  //数组中元素交换
    static void swap(int [] arr,int i,int j){
        int temp ;
        temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
```
2. 数学方法

```
 //数组中元素交换
    static void swap(int [] arr,int i,int j){
        arr[i] = arr[i] + arr[j];
        arr[j] = arr[i] - arr[j];
        arr[i] = arr[i] - arr[j];
    }
```


3. 位运算实现
```
    //数组中元素交换
    static void swap(int [] arr,int i,int j){
        arr[i] = arr[i] ^ arr[j];
        arr[j] = arr[i] ^ arr[j];
        arr[i] = arr[i] ^ arr[j];
    }
```

*程序中所有的树在计算机内存中以二进制存储。位运算就是直接对整数在内存中的二进制位进行操作。由于位运算直接对内存数据进行操作，不需要转成十进制，因此处理速度非常快。*

C/C++中可实现指针传递。所以可以不用引用数组二直接交换两个变量的值。

```
void swap(int &a,int &b){
	int temp = a;
	a = b;
	b = a;
}
```
