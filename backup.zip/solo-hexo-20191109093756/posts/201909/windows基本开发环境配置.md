title: windows基本开发环境配置
date: '2019-09-27 16:26:00'
updated: '2019-10-04 15:29:27'
tags: [填坑记]
permalink: /articles/2019/09/27/1569572760512.html
---
&emsp;&emsp;在测试maven项目时，发现无论怎么改maven的包一直下载不下来，找了好多方法都没有成功，最后发现是系统的问题，好坑啊。重装了windows系统后，需要重新配开发环境。本文讲了jdk环境的配置和mysql的基本配置
1. 在官网上下载安装包，选择接受协议
https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
![image.png](https://img.hacpai.com/file/2019/09/image-e9bae859.png)
2. 点击运行安装包，一路点确定
![image.png](https://img.hacpai.com/file/2019/09/image-b0cb6bf8.png)
箭头指的是安装路径，建议装在C盘。如果需要更改路径，点击更改。（这个是JDK的安装位置）
![image.png](https://img.hacpai.com/file/2019/09/image-f1456a35.png)
3. 这个是jre（运行环境）的安装位置
![image.png](https://img.hacpai.com/file/2019/09/image-38ede2e4.png)

4. 安装完成，点击关闭
![image.png](https://img.hacpai.com/file/2019/09/image-ee7e0b1a.png)

5. 配置环境变量
在系统变量的环境变量中新建
```JAVA_HOME```
选择JDK的安装路径。默认为
``` C:\Program Files\Java\jdk1.8.0_221```
找到系统变量中的path变量，选中，点击编辑，然后新建
```%JAVA_HOME%\bin```
继续新建
```%JAVA_HOME%\jre\bin```
新建ClassPath环境变量，点击编辑，新建
```.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar; ```
确认后关闭


**安装mysql**

1. [MySQL安装和重置密码]**  
[查看博客](https://blog.csdn.net/xsfqh/article/details/90085168#commentBox)  
  
2. [初次修改密码]
[查看博客](https://www.cnblogs.com/gkx0731/p/9739241.html)  
  
3. [在使用Navicat Premium 12连接MySQL数据库时会出现Authentication plugin 'caching_sha2_password' cannot be loaded的错误]**
[查看解决方法](https://blog.csdn.net/u011182575/article/details/80821418)
