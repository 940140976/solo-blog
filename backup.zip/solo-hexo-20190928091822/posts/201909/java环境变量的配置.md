title: java环境变量的配置
date: '2019-09-27 16:26:00'
updated: '2019-09-27 20:17:29'
tags: [java]
permalink: /articles/2019/09/27/1569572760512.html
---
&emsp;&emsp;在测试maven项目时，发现无论怎么改maven的包一直下载不下来，找了好多方法都没有成功，猜测是系统的问题，便重装了系统。现在在一个什么都没有的电脑，从java环境变量开始配起。
1. 在官网上下载安装包，选择接受协议
https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
![image.png](https://img.hacpai.com/file/2019/09/image-e9bae859.png)
2. 点击运行安装包，一路点确定
![image.png](https://img.hacpai.com/file/2019/09/image-b0cb6bf8.png)
箭头指的是安装路径，建议装在C盘。如果需要更改路径，点击更改。（这个是JDK的安装位置）
![image.png](https://img.hacpai.com/file/2019/09/image-f1456a35.png)
如下图，正在安装
![image.png](https://img.hacpai.com/file/2019/09/image-288d9ad8.png)
3. 这个是jre（运行环境）的安装位置
![image.png](https://img.hacpai.com/file/2019/09/image-38ede2e4.png)

4. 安装完成，点击关闭
![image.png](https://img.hacpai.com/file/2019/09/image-ee7e0b1a.png)

5. 配置环境变量
在系统变量的环境变量中新建
```JAVA_HOME```
选择JDK的安装路径。默认为
``` C:\Program Files\Java\jdk1.8.0_221```
找到系统变量中的path变量，选中，点击编辑，然后新建
```%JAVA_HOME%\bin```
继续新建
```%JAVA_HOME%\jre\bin```
新建ClassPath环境变量，点击编辑，新建
```.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar; ```
确认后关闭
