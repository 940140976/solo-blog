title: CentOS7.3下Nginx的安装
date: '2019-10-04 17:49:00'
updated: '2019-10-04 17:49:13'
tags: [nginx]
permalink: /articles/2019/10/04/1570182540883.html
---
&emsp;&emsp;前阵子域名备案成功，博客也搭建好了，但是会暴露出来端口号，决定学学nginx反向代理。

1. 安装
安装之前的准备：
&emsp;&emsp;设置yum存储库，请创建`/etc/yum.repos.d/nginx.repo` 包含以下内容的文件 ：
```
[nginx-stable]
name=nginx stable repo
baseurl=http://nginx.org/packages/centos/$releasever/$basearch/
gpgcheck=1
enabled=1
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true

[nginx-mainline]
name=nginx mainline repo
baseurl=http://nginx.org/packages/mainline/centos/$releasever/$basearch/
gpgcheck=1
enabled=0
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true
```

安装nginx
```
sudo yum install nginx
```

2. 匹配值文件时遇到的一些问题

![image.png](https://img.hacpai.com/file/2019/10/image-80fd8bb8.png)
查看所有端口
`netstat -ntlp`
关闭进程
`kill 1386`
![image.png](https://img.hacpai.com/file/2019/10/image-4e414959.png)

