title: 数据结构C语言实现（二）线性表
date: '2019-10-07 09:35:40'
updated: '2019-10-07 20:54:11'
tags: [数据结构]
permalink: /articles/2019/10/07/1570412140078.html
---
<h3>基本概念</h3>
线性表：由n（n>=0）个数据特性元素相同的元素构成的有限序列称为线性表。
<br/>
空表：当n=0时。
<br/>
基本特点：除第一个元素无直接前驱，最后一个元素无直接后继外，其他每一个数据元素都有一个前去和后继。
<br/>
<h3>线性表的顺序表示和实现</h3>
顺序表：用一组地址连续的存储单元一此存储线性表的数据元素。
特点：逻辑上相邻的元素，物理次序也相邻。
<h4>存储结构</h4>
在C语言中，可用动态分配的一维数组表示线性表（下标从0开始）。


```
#define OK 1
#define ERROR 0
#define OVERFLOW -2

//Status是函数返回值类型,其值是还结果的状态码
typedef int Status; 
//定义ELemType的数据类型
typedef int ElemType;
/-----顺序表的存储结构------/
#define MAXSIZE 100						//顺序表可能达到的最大长度
typedef struct{
ElemType *elem;						//存储空间的基地址
int length;							//当前长度
}SqList;
	
```

<h4>相关运算</h4>
1. 初始化
<br/>
2. 取值
<br/>
3. 查找
<br/>
4. 插入
<br/>
5. 删除
<br/>
<h5>初始化</h5>

```
	 //为顺序表L分配一个预定义大小的数组空间
	 //价格表的当前长度设为0
	 Status InitList(SqList &L){
	 	//构造一个空的顺序表L
		 L.elem = new ElemType[MAXSIZE];	//为顺序表分配一个大小为MAXSIZE的数组空间 （指针赋值为地址）
		 if(!L.elem) exit(OVERFLOW);		//存储分配失败退出
		 L.length = 0;						//空表长度为0 
		 return OK; 
	 } 

```
<h5>取值</h5>

```
	 /---说明： 根据指定的位置序号，获取顺序表中第i个元素值---/ 
	 /------判断指定位置的序号i是否合理（1<=i<=L.length） ，若不合理，返回ERROR。 
	 		若i值合理，则将第i个数据元素L.elem[i-1]赋给参数e返回第i个元素的传值。 ----/
	Status GetElem(SqList L,int i,ElemType &e){
		if(i<1||i>L.length) return ERROR;				//判断i值是否合理（1<=i<=L.length） ，若不合理，返回ERROR。
		e = L.elem[i - 1];								//elem[i-1]单元存储第i个元素 
		 return OK;
	}
```
`时间复杂度分析：容易看出来，顺序表取值算法的时间复杂度为O（1）`

<h5>查找</h5>

```
	/---说明：给定元素e查找表中第一个与e相同的元素---/
	 /---从第一个元素起，依次和e比较 ，若找到与e相等的元素L.elem[i],则查找成功，该元素的序号i+1。 
	 		若查遍整个表都没有找到，则查找失败，返回0。----/
			 int LocateElem(SqList L,ElemType e){
			 	//在顺序表中查找值为e的元素
				 for(int i = 0;i < L.length;i++)
				 if(L.elem[i]==e) return i+1; 			//查找成功，返回序号i+1
				 return 0;								//查找失败，返回0
			 }
```

<h5>插入</h5>

```
/----说明：在表的第i个位置插入一个新的数据元素e。L。length+=1;
Status ListInsert (SqList &L,int i,ElemType e){
	//在顺序表中第
}
```
<h5>删除</h5>
